package com.example.controlefinanceiro.adapters;

public class AdapterDespesa {
}

package com.example.controlefinanceiro.persistencia;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.media.RouteListingPreference;
import android.util.Log;

import com.example.controlefinanceiro.model.Categoria;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class CategoriaDAO implements ICrudDAO<Categoria> {

    private SQLiteDatabase dbEscreve;
    private SQLiteDatabase dbLe;
    public CategoriaDAO(Context context) {
        DbHelper db = new DbHelper(context);
        dbEscreve = db.getWritableDatabase();
        dbLe = db.getReadableDatabase();
    }
    @Override
    public boolean salvar(Categoria categoria) {
        ContentValues cv = new ContentValues();
        cv.put("descricaoCategoria", categoria.getDescricaoCategoria());
        try {
            dbEscreve.insert(DbHelper.TB_CATEGORIAS, null, cv);
            Log.i("InfoDB", "Sucesso ao salvar o registro na tabela Categoria");
        } catch (Exception e) {
            Log.i("InfoDB", "Erro ao salvar o registro na tabela Categoria");
            return false;
        }
        return true;
    }

    @Override
    public boolean alterar(Categoria item) {
        ContentValues cv = new ContentValues();
        cv.put("descricaoCategoria", item.getDescricaoCategoria());
        try {
            long id = dbEscreve.insert(DbHelper.TB_CATEGORIAS, null, cv);
            if (id != -1) {
                Log.i("InfoDB", "Sucesso ao salvar o registro na tabela Categoria");
                return true;
            } else {
                Log.i("InfoDB", "Erro ao salvar o registro na tabela Categoria");
                return false;
            }
        } catch (Exception e) {
            Log.e("InfoDB", "Erro ao salvar o registro: " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean deletar(Categoria item) {
        try {
            String[] args = { String.valueOf(item.getIdCategoria())};
            dbEscreve.delete(DbHelper.TB_CATEGORIAS, "id=?", args);
            Log.i("InfoDB", "Sucesso ao excluir o registro");
        } catch (Exception e) {
            Log.i("InfoDB", "Erro ao excluir o registro");
            return false;
        }
        return true;
    }

    @Override
    public List<Categoria> listarTodos() {
        List<Categoria> lstCategorias = new ArrayList<>();
        String sql = "SELECT * FROM " + DbHelper.TB_CATEGORIAS + ";";
        Cursor cursor = dbLe.rawQuery(sql, null);
        while (cursor.moveToNext()) {
            Categoria categoria = new Categoria();
            Integer id = cursor.getInt(cursor.getColumnIndex("id_categoria"));
            String descricaoCategoria = cursor.getString(cursor.getColumnIndex("descricao_nome"));
            categoria.setIdCategoria(id);
            categoria.setDescricaoCategoria(descricaoCategoria);
            lstCategorias.add(categoria);
            Log.i("InfoDB", "Sucesso ao pesquisar o registro na tabela ");
        }

        return lstCategorias;
    }

    @Override
    public Categoria ListarPorId(int id) {
        String[] columns = {"id_categoria", "descricao_nome"};
        String selection = "id_categoria = ?";
        String[] selectionArgs = {String.valueOf(id)};

        try (Cursor cursor = dbLe.query(DbHelper.TB_CATEGORIAS, columns, selection, selectionArgs, null, null, null)) {
            if (cursor.moveToFirst()) {
                int idCategoria = cursor.getInt(cursor.getColumnIndex("id_categoria"));
                String descricaoCategoria = cursor.getString(cursor.getColumnIndex("descricao_nome"));
                return new Categoria(idCategoria, descricaoCategoria);
            }
        }
        return null;
    }
}

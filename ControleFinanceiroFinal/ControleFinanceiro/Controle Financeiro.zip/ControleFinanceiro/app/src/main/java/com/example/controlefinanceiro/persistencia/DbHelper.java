package com.example.controlefinanceiro.persistencia;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DbHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "financeiro.db";
    private static final int DATABASE_VERSION = 1;
    public static final String TB_DESPESAS = "despesas";
    public static final String TB_RECEITAS = "receitas";
    public static final String TB_CATEGORIAS = "categorias";
    //Criação da Tabela de Desepesas
    private static final String SQL_CREATE_DESPESAS =
            "CREATE TABLE IF NOT EXISTS " + TB_DESPESAS + " (" +
                    "id_despesa INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "descricao_despesa TEXT, " +
                    "valor_despesa DOUBLE, " +
                    "data_despesa TEXT, " +
                    "id_categoria INTEGER);";
    //Criação da Tabela de Receitas
    private static final String SQL_CREATE_RECEITAS =
            "CREATE TABLE IF NOT EXISTS " + TB_RECEITAS + " (" +
                    "id_receita INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "descricao_receita TEXT, " +
                    "valor_receita DOUBLE, " +
                    "data_receita TEXT, " +
                    "id_categoria INTEGER);";
    //Criação da Tabela de Categorias
    private static final String SQL_CREATE_CATEGORIAS =
            "CREATE TABLE IF NOT EXISTS " + TB_CATEGORIAS + " (" +
                    "id_categoria INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "descricao_categoria TEXT NOT NULL);";

    private static final String SQL_DELETE_DESPESAS = "DROP TABLE IF EXISTS " + TB_DESPESAS;
    private static final String SQL_DELETE_RECEITAS = "DROP TABLE IF EXISTS " + TB_RECEITAS;
    private static final String SQL_DELETE_CATEGORIAS = "DROP TABLE IF EXISTS " + TB_CATEGORIAS;

    public DbHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        executeSql(db, SQL_CREATE_DESPESAS, "DESPESAS");
        executeSql(db, SQL_CREATE_RECEITAS, "RECEITAS");
        executeSql(db, SQL_CREATE_CATEGORIAS, "CATEGORIAS");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        executeSql(db, SQL_DELETE_DESPESAS, "DESPESAS");
        executeSql(db, SQL_DELETE_RECEITAS, "RECEITAS");
        executeSql(db, SQL_DELETE_CATEGORIAS, "CATEGORIAS");
        onCreate(db);
    }
    //Criada uma função executeSql para reduzir a repetição de código nos métodos, objetivo de melhorar a legibilidade
    private void executeSql(SQLiteDatabase db, String sql, String tableName) {
        try {
            db.execSQL(sql);
            Log.i("INFO DB", "SUCESSO AO CRIAR A TABELA " + tableName);
        } catch (Exception e) {
            Log.e("INFO DB", "ERRO AO CRIAR A TABELA " + tableName + " " + e.getMessage());
        }
    }
}

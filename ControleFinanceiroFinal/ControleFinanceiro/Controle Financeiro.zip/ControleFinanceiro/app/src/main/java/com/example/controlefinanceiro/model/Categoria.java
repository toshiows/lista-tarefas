package com.example.controlefinanceiro.model;

import com.example.controlefinanceiro.persistencia.ICrudDAO;

public class Categoria {
    private int idCategoria;
    private String descricaoCategoria;

    public Categoria() {
    }

    // Construtor com parâmetros
    public Categoria(int idCategoria, String descricaoCategoria) {
        this.idCategoria = idCategoria;
        this.descricaoCategoria = descricaoCategoria;
    }

    public int getIdCategoria() {
        return idCategoria;
    }

    public void setIdCategoria(int idCategoria) {
        this.idCategoria = idCategoria;
    }

    public String getDescricaoCategoria() {
        return descricaoCategoria;
    }

    public void setDescricaoCategoria(String descricaoCategoria) {
        this.descricaoCategoria = descricaoCategoria;
    }
}
